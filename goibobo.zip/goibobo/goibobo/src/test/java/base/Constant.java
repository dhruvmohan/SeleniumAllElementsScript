package base;

public class Constant {

	public static final String Browser = "chrome";
	
	public static final String testsiteURL= "https://www.goibibo.com/#";
	
	}
